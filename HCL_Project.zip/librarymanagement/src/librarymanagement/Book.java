package librarymanagement;

abstract class Book {
    String title;
    String author;
    String genre;
    boolean isBorrowed;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isBorrowed = false;
    }
}
