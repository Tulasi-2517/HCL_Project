package librarymanagement;

interface Observer {
    void update(String message);
}
