package librarymanagement;

import java.util.ArrayList;
import java.util.List;

class Member {
    String name;
    List<Book> borrowedBooks;

    public Member(String name) {
        this.name = name;
        this.borrowedBooks = new ArrayList<>();
    }

    public void borrowBook(Book book) {
        borrowedBooks.add(book);
        book.isBorrowed = true;
    }

    public void returnBook(Book book) {
        borrowedBooks.remove(book);
        book.isBorrowed = false;
    }
}
