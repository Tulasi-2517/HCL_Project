package librarymanagement;

class BookFactory {
    public static Book createBook(String genre, String title, String author) {
        if (genre.equalsIgnoreCase("Fiction")) {
            return new FictionBook(title, author);
        } else if (genre.equalsIgnoreCase("Non-Fiction")) {
            return new NonFictionBook(title, author);
        }
        return null;
    }
}
