package librarymanagement;

import java.time.LocalDate;

class Librarian {
    public void addBook(Book book, Library library) {
        library.addBook(book);
    }

    public void removeBook(Book book, Library library) {
        library.removeBook(book);
    }

    public void issueBook(Book book, Member member, Library library) {
        if (!book.isBorrowed) {
            member.borrowBook(book);
            Transaction transaction = new Transaction(member, book, "Issue");
            library.addTransaction(transaction);
            LocalDate issueDate = transaction.transactionDate;
            LocalDate dueDate = issueDate.plusDays(7);
            String message = String.format("Book \"%s\" issued to %s on %s. Due date is %s.",
                                           book.title, member.name, issueDate, dueDate);
            library.notifyObservers(message, member);
            System.out.println(message);  // Print the issue notification
        } else {
            System.out.println("Book is already borrowed.");
        }
    }

    public void returnBook(Book book, Member member, Library library) {
        if (book.isBorrowed) {
            member.returnBook(book);
            Transaction transaction = new Transaction(member, book, "Return");
            library.addTransaction(transaction);
            String message = String.format("Book \"%s\" returned by %s", book.title, member.name);
            library.notifyObservers(message, member);
            System.out.println(message);  // Print the return notification
        } else {
            System.out.println("Book was not borrowed.");
        }
    }
}
