package librarymanagement;

import java.time.LocalDate;

class Transaction {
    Member member;
    Book book;
    String transactionType;
    LocalDate transactionDate;

    public Transaction(Member member, Book book, String transactionType) {
        this.member = member;
        this.book = book;
        this.transactionType = transactionType;
        this.transactionDate = LocalDate.now();
    }
}
