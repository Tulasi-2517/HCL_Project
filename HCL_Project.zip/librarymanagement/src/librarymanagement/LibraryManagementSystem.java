package librarymanagement;

import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = Library.getInstance();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Library Management System");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Add Book");
            System.out.println("2. Issue Book");
            System.out.println("3. Return Book");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addBook(library, scanner);
                    break;
                case 2:
                    issueBook(library, scanner);
                    break;
                case 3:
                    returnBook(library, scanner);
                    break;
                case 4:
                    System.out.println("Exiting the Library Management System. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addBook(Library library, Scanner scanner) {
        System.out.print("Enter book genre (Fiction/Non-Fiction): ");
        String genre = scanner.nextLine();
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();
        System.out.print("Enter book author: ");
        String author = scanner.nextLine();

        Book book = BookFactory.createBook(genre, title, author);
        if (book != null) {
            new Librarian().addBook(book, library);
            System.out.println("Book added successfully.");
        } else {
            System.out.println("Invalid genre. Book not added.");
        }
    }

    private static void issueBook(Library library, Scanner scanner) {
        System.out.print("Enter member name: ");
        String memberName = scanner.nextLine();
        Member member = getOrCreateMember(memberName, library);

        System.out.print("Enter book title to issue: ");
        String title = scanner.nextLine();

        Book book = findBookByTitle(library, title);
        if (book != null && !book.isBorrowed) {
            new Librarian().issueBook(book, member, library);
        } else {
            System.out.println("Book not found or already issued.");
        }
    }

    private static void returnBook(Library library, Scanner scanner) {
        System.out.print("Enter member name: ");
        String memberName = scanner.nextLine();
        Member member = getOrCreateMember(memberName, library);

        System.out.print("Enter book title to return: ");
        String title = scanner.nextLine();

        Book book = findBookByTitle(library, title);
        if (book != null && book.isBorrowed) {
            new Librarian().returnBook(book, member, library);
        } else {
            System.out.println("Book not found or not issued.");
        }
    }

    private static Member getOrCreateMember(String name, Library library) {
        
        return new Member(name);
    }

    private static Book findBookByTitle(Library library, String title) {
        for (Book book : library.getBooks()) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }
}
